package com.tweetapp.demo.dtomodels;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor @AllArgsConstructor @Data
public class RlyTweet {

    private String rlyBy;
    private String rlyCont;

}
