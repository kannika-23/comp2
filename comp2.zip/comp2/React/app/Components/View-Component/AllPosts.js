import React, { useEffect, useContext } from "react";
import axios from "axios";
import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import StateContext from "../../Context/StateContext-Provider";
import LoadingComponent from "../Loading-Component/Loading";
function AllPosts() {
  const { username } = useParams();
  const [isLoading, setIsLoading] = useState(true);
  const [posts, setPosts] = useState([]);
  const appState = useContext(StateContext);
  useEffect(() => {
    async function getPosts() {
      console.log("in getPosts");
      try {
       var username = appState.user.username;
        var token = appState.user.token;
        console.log(username + " " + token);
        let config = {
          headers: {
            Authorization: token,
          },
        };
        setIsLoading(false);
        //http://localhost:9000/profile/ak/posts
        const response = await axios.get(`/tweets/all`, config);
        console.log("in try block");
        console.log(response.data);
        setPosts(response.data);
      } catch (e) {
        console.log(e);
        console.log("There was an error");
      }
    }
    getPosts();
  }, []);
  //console.log("in post");
  if (isLoading) {
    return (
      <div>
        <LoadingComponent />
      </div>
    );
  }
  return (
    <div className="list-group">
      {posts.map(post => {
        const date = new Date(post.createdDate);
        const DateFormat = `${
          date.getMonth() + 1
        }/${date.getDate()}/${date.getFullYear()}`;
        return (
          <Link
            key={post.tweetId}
            to={`/post/${post._id}`}
            className="list-group-item list-group-item-action"
          >
            {/* <img className="avatar-tiny" src={post.tweetBy} />{" "} */}
            <italic>#{post.hashTag}</italic>
            <br />
            <strong>{post.tweetContent}</strong>{" "}
            <span className="text-muted small">on {post.postDate} </span>
          </Link>
        );
      })}
    </div>
  );
}

export default AllPosts;
