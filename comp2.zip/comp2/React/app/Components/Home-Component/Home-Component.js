import React from "react";
import Page from "../Page-Component/Page";
import { useContext, useState, useEffect } from "react";
import StateContext from "../../Context/StateContext-Provider";
import AllPosts from "../View-Component/AllPosts";
import LoadingComponent from "../Loading-Component/Loading";
function HomeComponent() {
  const appState = useContext(StateContext);
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function getPosts() {
      console.log("in getPosts");
      try {
       var username = appState.user.username;
        var token = appState.user.token;
        console.log(username + " " + token);
        let config = {
          headers: {
            Authorization: token,
          },
        };
        setIsLoading(false);
        //http://localhost:9000/profile/ak/posts
        const response = await axios.get(`/tweets/all`, config);
        console.log("in try block");
        console.log(response.data);
        setPosts(response.data);
      } catch (e) {
        console.log(e);
        console.log("There was an error");
      }
    }
    getPosts();
  }, []);
  if (isLoading) {
    return (
      <div>
        <LoadingComponent />
      </div>
    );
  }
  return (
    <Page title="Home Feed">
      <h2 className="text-center">
        Hello <strong>{appState.user.username}</strong>, your feed is empty.
      </h2>
      {posts === null ? 
      <p className="lead text-muted text-center">
        Your feed displays the latest posts from the people you follow. If you
        don&rsquo;t have any friends to follow that&rsquo;s okay; you can use
        the &ldquo;Search&rdquo; feature in the top menu bar to find content
        written by people with similar interests and then follow them.
      </p>
      :
      <AllPosts/>
      }
      
    </Page>
  );
}

export default HomeComponent;
