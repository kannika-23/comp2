import { createContext } from "react";

const ParentContext = createContext();

export default ParentContext;
